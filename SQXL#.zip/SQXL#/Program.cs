using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

public class DataApp : Form {
    // --- DirectDraw 7 Native COM Interop ---
    private static class DirectDraw {
        [DllImport("ddraw.dll")]
        public static extern int DirectDrawCreateEx(IntPtr guid, out IntPtr dd, ref Guid iid, IntPtr outer);

        public static Guid IID_IDirectDraw7 = new Guid("15e65ec0-3b9c-11d2-b92f-00609797ea5b");

        [StructLayout(LayoutKind.Sequential)]
        public struct DDSURFACEDESC2 {
            public int dwSize;
            public int dwFlags;
            public int dwHeight;
            public int dwWidth;
            public int lPitch;
            public int dwBackBufferCount;
            public int dwRefreshRate;
            public int dwReserved;
            public IntPtr lpSurface;
            public DDSCAPS2 ddsCaps;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct DDSCAPS2 {
            public int dwCaps, dwCaps2, dwCaps3, dwCaps4;
        }

        public const int SetCooperativeLevel = 20;
        public const int CreateSurface = 6;
        public const int GetDC = 17;
        public const int ReleaseDC = 26;
        public const int Lock = 25;
        public const int Unlock = 32;

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        public delegate int SetCoopDelegate(IntPtr inst, IntPtr hwnd, int flags);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        public delegate int CreateSurfDelegate(IntPtr inst, ref DDSURFACEDESC2 desc, out IntPtr surf, IntPtr outer);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        public delegate int GetDCDelegate(IntPtr surf, out IntPtr hdc);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        public delegate int ReleaseDCDelegate(IntPtr surf, IntPtr hdc);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        public delegate int LockDelegate(IntPtr surf, IntPtr rect, ref DDSURFACEDESC2 desc, int flags, IntPtr hEvent);
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        public delegate int UnlockDelegate(IntPtr surf, IntPtr rect);
    }

    private IntPtr _dd7 = IntPtr.Zero;
    private IntPtr _primarySurf = IntPtr.Zero;
    private DirectDraw.GetDCDelegate _getDC;
    private DirectDraw.ReleaseDCDelegate _releaseDC;
    private DirectDraw.LockDelegate _lockSurf;
    private DirectDraw.UnlockDelegate _unlockSurf;

    private Bitmap _backBuffer;
    private Bitmap _middleBuffer;
    private readonly object _bufferLock = new object();

    private TabControl tabs;
    private RichTextBox sqlInput;
    private Label status;
    private Label lineCountLabel;
    private ListBox completionList;
    private ContextMenuStrip tabMenu;
    private FlowLayoutPanel btnPanel;
    private Dictionary<string, DataTable> activeData = new Dictionary<string, DataTable>();
    private bool _isColoring = false;

    private static class SQLite {
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_open", CallingConvention = CallingConvention.Cdecl)]
        public static extern int Open(string filename, out IntPtr db);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_close", CallingConvention = CallingConvention.Cdecl)]
        public static extern int Close(IntPtr db);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_exec", CallingConvention = CallingConvention.Cdecl)]
        public static extern int Exec(IntPtr db, byte[] sql, IntPtr callback, IntPtr args, out IntPtr errmsg);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_prepare_v2", CallingConvention = CallingConvention.Cdecl)]
        public static extern int Prepare(IntPtr db, byte[] sql, int nByte, out IntPtr stmt, IntPtr tail);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_step", CallingConvention = CallingConvention.Cdecl)]
        public static extern int Step(IntPtr stmt);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_column_text", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr ColumnText(IntPtr stmt, int iCol);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_column_name", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr ColumnName(IntPtr stmt, int iCol);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_column_count", CallingConvention = CallingConvention.Cdecl)]
        public static extern int ColumnCount(IntPtr stmt);
        [DllImport("sqlite3.dll", EntryPoint = "sqlite3_finalize", CallingConvention = CallingConvention.Cdecl)]
        public static extern int Finalize(IntPtr stmt);

        public static byte[] ToUtf8(string s) { return Encoding.UTF8.GetBytes(s + "\0"); }
        public static string FromUtf8(IntPtr ptr) {
            if (ptr == IntPtr.Zero) return "";
            int len = 0; while (Marshal.ReadByte(ptr, len) != 0) len++;
            byte[] buffer = new byte[len]; Marshal.Copy(ptr, buffer, 0, len);
            return Encoding.UTF8.GetString(buffer);
        }
    }

    public DataApp() {
        this.Text = "SQXL# Ultra - C# 5.0 DirectDraw Edition";
        this.Size = new Size(1100, 800);
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.Opaque, true);

        InitDirectDraw();

        tabMenu = new ContextMenuStrip();
        tabMenu.Items.Add("Close Tab", null, delegate { CloseCurrentTab(); });

        Panel topPanel = new Panel { Dock = DockStyle.Top, Height = 150, Padding = new Padding(10) };
        sqlInput = new RichTextBox { Dock = DockStyle.Fill, Font = new Font("Consolas", 11), Text = "SELECT * FROM TableA", AcceptsTab = false };
        sqlInput.TextChanged += delegate { ColorizeSql(); };
        sqlInput.KeyDown += SqlInput_KeyDown;

        completionList = new ListBox { Visible = false, Width = 180, Height = 120, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 9) };
        this.Controls.Add(completionList);

        btnPanel = new FlowLayoutPanel { Dock = DockStyle.Right, Width = 160 };
        Button btnLoad = new Button { Text = "Add File(s)", Width = 140 };
        btnLoad.Click += delegate { ChooseFile(); };
        Button btnRun = new Button { Text = "Run SQL", Width = 140, BackColor = Color.LightGreen };
        btnRun.Click += delegate { RunQuery(); };
        Button btnClear = new Button { Text = "Clear All Tabs", Width = 140 };
        btnClear.Click += delegate { ClearAllTabs(); };
        Button btnExport = new Button { Text = "Export CSV", Width = 140 };
        btnExport.Click += delegate { ExportToCsv(); };

        btnPanel.Controls.Add(btnLoad); btnPanel.Controls.Add(btnRun); 
        btnPanel.Controls.Add(btnClear); btnPanel.Controls.Add(btnExport);
        topPanel.Controls.Add(sqlInput); topPanel.Controls.Add(btnPanel);

        tabs = new TabControl { Dock = DockStyle.Fill };
        tabs.SelectedIndexChanged += delegate { UpdateLineCount(); };
        tabs.MouseDown += Tabs_MouseDown; 

        Panel statusStrip = new Panel { Dock = DockStyle.Bottom, Height = 25, BorderStyle = BorderStyle.Fixed3D };
        status = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Text = "Ready" };
        lineCountLabel = new Label { Dock = DockStyle.Right, Width = 200, TextAlign = ContentAlignment.MiddleRight, Text = "Rows: 0" };
        statusStrip.Controls.Add(status); statusStrip.Controls.Add(lineCountLabel);

        this.Controls.Add(tabs); this.Controls.Add(topPanel); this.Controls.Add(statusStrip);
        this.Resize += delegate { CreateBuffers(); };
        CreateBuffers();
        ColorizeSql();
    }

    private void InitDirectDraw() {
        try {
            if (DirectDraw.DirectDrawCreateEx(IntPtr.Zero, out _dd7, ref DirectDraw.IID_IDirectDraw7, IntPtr.Zero) != 0) return;
            
            IntPtr vTable = Marshal.ReadIntPtr(_dd7);
            IntPtr setCoopPtr = Marshal.ReadIntPtr(vTable, DirectDraw.SetCooperativeLevel * IntPtr.Size);
            var setCoop = (DirectDraw.SetCoopDelegate)Marshal.GetDelegateForFunctionPointer(setCoopPtr, typeof(DirectDraw.SetCoopDelegate));
            
            setCoop(_dd7, this.Handle, 0x00000008); // DDSCL_NORMAL

            DirectDraw.DDSURFACEDESC2 desc = new DirectDraw.DDSURFACEDESC2();
            desc.dwSize = Marshal.SizeOf(typeof(DirectDraw.DDSURFACEDESC2));
            desc.dwFlags = 0x00000001; // DDSD_CAPS
            desc.ddsCaps.dwCaps = 0x00000200; // DDSCAPS_PRIMARYSURFACE

            IntPtr createSurfPtr = Marshal.ReadIntPtr(vTable, DirectDraw.CreateSurface * IntPtr.Size);
            var createSurf = (DirectDraw.CreateSurfDelegate)Marshal.GetDelegateForFunctionPointer(createSurfPtr, typeof(DirectDraw.CreateSurfDelegate));
            
            if (createSurf(_dd7, ref desc, out _primarySurf, IntPtr.Zero) == 0) {
                IntPtr sVTable = Marshal.ReadIntPtr(_primarySurf);
                _getDC = (DirectDraw.GetDCDelegate)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(sVTable, DirectDraw.GetDC * IntPtr.Size), typeof(DirectDraw.GetDCDelegate));
                _releaseDC = (DirectDraw.ReleaseDCDelegate)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(sVTable, DirectDraw.ReleaseDC * IntPtr.Size), typeof(DirectDraw.ReleaseDCDelegate));
                _lockSurf = (DirectDraw.LockDelegate)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(sVTable, DirectDraw.Lock * IntPtr.Size), typeof(DirectDraw.LockDelegate));
                _unlockSurf = (DirectDraw.UnlockDelegate)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(sVTable, DirectDraw.Unlock * IntPtr.Size), typeof(DirectDraw.UnlockDelegate));
            }
        } catch { /* Fallback */ }
    }

    private void CleanupDirectDraw() {
        lock (_bufferLock) {
            if (_primarySurf != IntPtr.Zero) {
                Marshal.Release(_primarySurf);
                _primarySurf = IntPtr.Zero;
            }
            if (_dd7 != IntPtr.Zero) {
                Marshal.Release(_dd7);
                _dd7 = IntPtr.Zero;
            }
        }
    }

    protected override void Dispose(bool disposing) {
        if (disposing) {
            CleanupDirectDraw();
            if (_backBuffer != null) _backBuffer.Dispose();
            if (_middleBuffer != null) _middleBuffer.Dispose();
        }
        base.Dispose(disposing);
    }

    private void CreateBuffers() {
        lock (_bufferLock) {
            if (_backBuffer != null) _backBuffer.Dispose();
            if (_middleBuffer != null) _middleBuffer.Dispose();
            if (this.Width > 0 && this.Height > 0) {
                _backBuffer = new Bitmap(this.Width, this.Height);
                _middleBuffer = new Bitmap(this.Width, this.Height);
            }
        }
    }

    protected override void OnPaint(PaintEventArgs e) {
        lock (_bufferLock) {
            if (_middleBuffer == null) {
                e.Graphics.Clear(this.BackColor);
                return;
            }

            if (_primarySurf != IntPtr.Zero && _getDC != null) {
                IntPtr hdcSurf;
                if (_getDC(_primarySurf, out hdcSurf) == 0) {
                    try {
                        using (Graphics gSurf = Graphics.FromHdc(hdcSurf)) {
                            gSurf.DrawImage(_middleBuffer, 0, 0);
                        }
                    } finally {
                        _releaseDC(_primarySurf, hdcSurf);
                    }
                }
            } else {
                e.Graphics.DrawImage(_middleBuffer, 0, 0);
            }
        }
    }

    private void UpdateTripleBuffer() {
        lock (_bufferLock) {
            if (_backBuffer == null) return;
            using (Graphics g = Graphics.FromImage(_backBuffer)) {
                g.Clear(this.BackColor);
            }
            if (_middleBuffer != null) _middleBuffer.Dispose();
            _middleBuffer = (Bitmap)_backBuffer.Clone();
        }
        this.Invalidate();
    }

    private bool IsRowEmpty(string[] fields) {
        if (fields == null || fields.Length == 0) return true;
        foreach (string f in fields) if (!string.IsNullOrWhiteSpace(f)) return false;
        return true;
    }

    private void SetLoading(bool isLoading, string msg) {
        this.BeginInvoke((MethodInvoker)delegate {
            foreach (Control c in btnPanel.Controls) c.Enabled = !isLoading;
            sqlInput.ReadOnly = isLoading;
            status.Text = isLoading ? msg : "Ready";
            this.Cursor = isLoading ? Cursors.WaitCursor : Cursors.Default;
            UpdateTripleBuffer(); 
        });
    }

    private void ChooseFile() {
        OpenFileDialog ofd = new OpenFileDialog { Filter = "Data Files|*.xlsx;*.csv", Multiselect = true };
        if (ofd.ShowDialog() == DialogResult.OK) {
            string[] files = ofd.FileNames;
            SetLoading(true, "Async Loading...");
            Task.Factory.StartNew(delegate {
                try {
                    foreach (string fileName in files) {
                        string ext = Path.GetExtension(fileName).ToLower();
                        if (ext == ".csv") {
                            DataTable dt = ParseCsv(fileName);
                            string name = CleanIdentifier(Path.GetFileNameWithoutExtension(fileName));
                            lock (activeData) { activeData[name] = dt; }
                        } else {
                            var sheets = ParseXlsxRobust(fileName);
                            lock (activeData) { 
                                foreach (KeyValuePair<string, DataTable> entry in sheets) activeData[entry.Key] = entry.Value; 
                            }
                        }
                    }
                    this.BeginInvoke((MethodInvoker)delegate { RefreshTabs(); ColorizeSql(); SetLoading(false, ""); });
                } catch (Exception ex) {
                    this.BeginInvoke((MethodInvoker)delegate { SetLoading(false, ""); MessageBox.Show(ex.Message); });
                }
            });
        }
    }

    private void RunQuery() {
        if (activeData.Count == 0) return;
        string sql = sqlInput.Text;
        SetLoading(true, "SQL Execution...");
        Task.Factory.StartNew(delegate {
            IntPtr db = IntPtr.Zero;
            try {
                if (SQLite.Open(":memory:", out db) != 0) return;
                Dictionary<string, DataTable> snapshot;
                lock (activeData) { snapshot = new Dictionary<string, DataTable>(activeData); }

                foreach (KeyValuePair<string, DataTable> kvp in snapshot) {
                    List<string> defs = new List<string>();
                    foreach (DataColumn col in kvp.Value.Columns) defs.Add(string.Format("[{0}] TEXT", col.ColumnName));
                    string create = string.Format("CREATE TABLE [{0}] ({1})", kvp.Key, string.Join(",", defs.ToArray()));
                    IntPtr err; SQLite.Exec(db, SQLite.ToUtf8(create), IntPtr.Zero, IntPtr.Zero, out err);
                    foreach (DataRow row in kvp.Value.Rows) InsertRow(db, kvp.Key, row);
                }

                IntPtr stmt;
                if (SQLite.Prepare(db, SQLite.ToUtf8(sql), -1, out stmt, IntPtr.Zero) == 0) {
                    DataTable res = new DataTable("Result");
                    int cc = SQLite.ColumnCount(stmt);
                    for (int j = 0; j < cc; j++) {
                        string n = SQLite.FromUtf8(SQLite.ColumnName(stmt, j));
                        string un = n; int count = 1; while (res.Columns.Contains(un)) un = string.Format("{0}_{1}", n, count++);
                        res.Columns.Add(un);
                    }
                    while (SQLite.Step(stmt) == 100) {
                        DataRow dr = res.NewRow();
                        for (int k = 0; k < cc; k++) dr[k] = SQLite.FromUtf8(SQLite.ColumnText(stmt, k));
                        res.Rows.Add(dr);
                    }
                    SQLite.Finalize(stmt);
                    this.BeginInvoke((MethodInvoker)delegate { AddDataTab("Result", res); tabs.SelectedIndex = tabs.TabCount - 1; SetLoading(false, ""); });
                } else { throw new Exception("SQL Error."); }
            } catch (Exception ex) { this.BeginInvoke((MethodInvoker)delegate { SetLoading(false, ""); MessageBox.Show(ex.Message); }); }
            finally { if (db != IntPtr.Zero) SQLite.Close(db); }
        });
    }

    private void InsertRow(IntPtr db, string tbl, DataRow row) {
        List<string> vals = new List<string>();
        foreach (object item in row.ItemArray) {
            string s = (item == null) ? "" : item.ToString();
            vals.Add(string.Format("'{0}'", s.Replace("'", "''")));
        }
        string ins = string.Format("INSERT INTO [{0}] VALUES ({1})", tbl, string.Join(",", vals.ToArray()));
        IntPtr err; SQLite.Exec(db, SQLite.ToUtf8(ins), IntPtr.Zero, IntPtr.Zero, out err);
    }

    private DataTable ParseCsv(string path) {
        DataTable dt = new DataTable();
        using (StreamReader sr = new StreamReader(path, Encoding.UTF8)) {
            string line; bool isFirst = true;
            while ((line = sr.ReadLine()) != null) {
                if (string.IsNullOrWhiteSpace(line)) continue;
                string[] parts = SplitCsvLine(line);
                if (isFirst) { foreach (string p in parts) dt.Columns.Add(CleanIdentifier(p)); isFirst = false; }
                else { if (IsRowEmpty(parts)) continue; while (dt.Columns.Count < parts.Length) dt.Columns.Add("Col" + dt.Columns.Count); dt.Rows.Add(parts); }
            }
        }
        return dt;
    }

    private Dictionary<string, DataTable> ParseXlsxRobust(string path) {
        var results = new Dictionary<string, DataTable>();
        using (ZipArchive arc = ZipFile.OpenRead(path)) {
            XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
            List<string> ss = new List<string>();
            var sse = arc.GetEntry("xl/sharedStrings.xml");
            if (sse != null) {
                using (Stream s = sse.Open()) {
                    ss = XDocument.Load(s).Descendants(ns + "t").Select(delegate(XElement x) { return x.Value; }).ToList();
                }
            }
            XDocument wb = XDocument.Load(arc.GetEntry("xl/workbook.xml").Open());
            foreach (XElement sh in wb.Descendants(ns + "sheet")) {
                string name = CleanIdentifier(sh.Attribute("name").Value);
                XAttribute relIdAttr = sh.Attribute(XName.Get("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships"));
                string id = (sh.Attribute("sheetId") == null) ? (relIdAttr == null ? "" : relIdAttr.Value) : sh.Attribute("sheetId").Value;
                var wse = arc.GetEntry(string.Format("xl/worksheets/sheet{0}.xml", id));
                if (wse == null) wse = arc.Entries.FirstOrDefault(delegate(ZipArchiveEntry e) { return e.FullName.EndsWith(string.Format("sheet{0}.xml", id)); });
                if (wse == null) continue;
                
                DataTable dt = new DataTable(name);
                using (Stream s = wse.Open()) {
                    XDocument wsXml = XDocument.Load(s); bool isFirst = true;
                    foreach (XElement row in wsXml.Descendants(ns + "row")) {
                        var cells = row.Descendants(ns + "c").ToList();
                        if (cells.Count == 0) continue; 
                        int maxIdx = 0; foreach (var c in cells) { int idx = GetColIdx(c.Attribute("r").Value); if (idx > maxIdx) maxIdx = idx; }
                        string[] tempRow = new string[maxIdx + 1];
                        foreach (XElement c in cells) {
                            int idx = GetColIdx(c.Attribute("r").Value); XElement v = c.Element(ns + "v");
                            if (v != null) {
                                bool isShared = (c.Attribute("t") != null && c.Attribute("t").Value == "s");
                                tempRow[idx] = isShared ? ss[int.Parse(v.Value)] : v.Value;
                            }
                        }
                        if (isFirst) { for (int k = 0; k < tempRow.Length; k++) dt.Columns.Add(CleanIdentifier(tempRow[k] ?? "Col" + k)); isFirst = false; continue; }
                        if (IsRowEmpty(tempRow)) continue;
                        DataRow dr = dt.NewRow(); for (int k = 0; k < tempRow.Length; k++) if (k < dt.Columns.Count) dr[k] = tempRow[k];
                        dt.Rows.Add(dr);
                    }
                }
                results.Add(name, dt);
            }
        }
        return results;
    }

    private string[] SplitCsvLine(string line) {
        List<string> fields = new List<string>(); StringBuilder sb = new StringBuilder(); bool inQuotes = false;
        foreach (char c in line) {
            if (c == '\"') inQuotes = !inQuotes;
            else if (c == ',' && !inQuotes) { fields.Add(sb.ToString().Trim(' ', '\"')); sb.Clear(); }
            else sb.Append(c);
        }
        fields.Add(sb.ToString().Trim(' ', '\"')); return fields.ToArray();
    }

    private string CleanIdentifier(string input) {
        if (string.IsNullOrEmpty(input)) return "Unknown";
        StringBuilder sb = new StringBuilder(); if (!char.IsLetter(input[0])) sb.Append("f_");
        foreach (char c in input) if (char.IsLetterOrDigit(c)) sb.Append(c); else sb.Append("_");
        return sb.ToString().Replace("__", "_").TrimEnd('_');
    }

    private int GetColIdx(string r) {
        string l = new string(r.TakeWhile(char.IsLetter).ToArray());
        int i = 0; foreach (char c in l) i = i * 26 + (c - 'A' + 1); return i - 1;
    }

    private void Tabs_MouseDown(object sender, MouseEventArgs e) {
        if (e.Button == MouseButtons.Right) {
            for (int i = 0; i < tabs.TabCount; i++) if (tabs.GetTabRect(i).Contains(e.Location)) { tabs.SelectedIndex = i; tabMenu.Show(tabs, e.Location); break; }
        }
    }
    private void CloseCurrentTab() {
        if (tabs.SelectedTab == null) return;
        lock (activeData) { activeData.Remove(tabs.SelectedTab.Text); }
        tabs.TabPages.Remove(tabs.SelectedTab); UpdateLineCount(); ColorizeSql();
    }
    private void ClearAllTabs() {
        if (MessageBox.Show("Clear all?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes) {
            tabs.TabPages.Clear(); lock (activeData) { activeData.Clear(); } UpdateLineCount(); ColorizeSql();
        }
    }
    private void RefreshTabs() {
        lock (activeData) {
            foreach (KeyValuePair<string, DataTable> kvp in activeData) {
                bool exists = false; foreach (TabPage t in tabs.TabPages) if (t.Text == kvp.Key) exists = true;
                if (!exists) AddDataTab(kvp.Key, kvp.Value);
            }
        }
        UpdateLineCount();
    }
    private void AddDataTab(string name, DataTable dt) {
        TabPage tp = new TabPage(name);
        DataGridView dgv = new DataGridView { Dock = DockStyle.Fill, DataSource = dt, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false, BackgroundColor = Color.White };
        tp.Controls.Add(dgv); tabs.TabPages.Add(tp);
    }
    private void ExportToCsv() {
        if (tabs.SelectedTab == null) return;
        DataGridView dgv = tabs.SelectedTab.Controls.OfType<DataGridView>().FirstOrDefault();
        if (dgv == null || !(dgv.DataSource is DataTable)) return;
        DataTable dt = ((DataTable)dgv.DataSource).Copy();
        SaveFileDialog sfd = new SaveFileDialog { Filter = "CSV|*.csv" };
        if (sfd.ShowDialog() == DialogResult.OK) {
            string path = sfd.FileName;
            SetLoading(true, "Exporting...");
            Task.Factory.StartNew(delegate {
                try {
                    StringBuilder sb = new StringBuilder();
                    int colCount = dt.Columns.Count;
                    string[] headers = new string[colCount];
                    for (int j = 0; j < colCount; j++) headers[j] = dt.Columns[j].ColumnName;
                    sb.AppendLine(string.Join(",", headers));
                    foreach (DataRow row in dt.Rows) {
                        object[] items = row.ItemArray; string[] cells = new string[items.Length];
                        for (int i = 0; i < items.Length; i++) {
                            string s = (items[i] == null) ? "" : items[i].ToString();
                            cells[i] = string.Format("\"{0}\"", s.Replace("\"", "\"\""));
                        }
                        sb.AppendLine(string.Join(",", cells));
                    }
                    File.WriteAllText(path, sb.ToString(), Encoding.UTF8);
                    this.BeginInvoke((MethodInvoker)delegate { SetLoading(false, ""); });
                } catch (Exception ex) { this.BeginInvoke((MethodInvoker)delegate { SetLoading(false, ""); MessageBox.Show(ex.Message); }); }
            });
        }
    }
    private void SqlInput_KeyDown(object sender, KeyEventArgs e) {
        if (completionList.Visible) {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter) { if (completionList.SelectedItem != null) { InsertSelectedCompletion(); e.Handled = true; e.SuppressKeyPress = true; return; } }
            if (e.KeyCode == Keys.Up) { if (completionList.SelectedIndex > 0) completionList.SelectedIndex--; e.Handled = true; return; }
            if (e.KeyCode == Keys.Down) { if (completionList.SelectedIndex < completionList.Items.Count - 1) completionList.SelectedIndex++; e.Handled = true; return; }
            if (e.KeyCode == Keys.Escape) { completionList.Visible = false; return; }
        }
        Timer t = new Timer { Interval = 1 }; t.Tick += delegate { t.Stop(); ShowAutocomplete(); }; t.Start();
    }
    private void ShowAutocomplete() {
        string word = GetCurrentWord(); if (string.IsNullOrEmpty(word)) { completionList.Visible = false; return; }
        List<string> sug = new List<string>(new string[] { "SELECT", "FROM", "WHERE", "JOIN", "ON", "LEFT", "LIMIT", "ORDER BY", "GROUP BY", "AND", "OR", "AS", "COUNT", "DISTINCT" });
        lock (activeData) { 
            foreach (string k in activeData.Keys) sug.Add(k); 
            foreach (DataTable dt in activeData.Values) foreach (DataColumn col in dt.Columns) sug.Add(col.ColumnName); 
        }
        var matches = sug.Distinct().Where(delegate(string s) { return s.StartsWith(word, StringComparison.OrdinalIgnoreCase); }).OrderBy(delegate(string s) { return s; }).ToList();
        if (matches.Count > 0) {
            completionList.Items.Clear(); foreach (string m in matches) completionList.Items.Add(m);
            completionList.SelectedIndex = 0; var pos = sqlInput.GetPositionFromCharIndex(sqlInput.SelectionStart);
            pos.Y += (int)sqlInput.Font.Height + 5; pos.X += sqlInput.Left; pos.Y += sqlInput.Top;
            completionList.Location = pos; completionList.Visible = true; completionList.BringToFront();
        } else completionList.Visible = false;
    }
    private string GetCurrentWord() {
        int pos = sqlInput.SelectionStart; if (pos == 0) return "";
        int start = pos - 1; while (start >= 0 && (char.IsLetterOrDigit(sqlInput.Text[start]) || sqlInput.Text[start] == '_')) start--;
        return sqlInput.Text.Substring(start + 1, pos - (start + 1));
    }
    private void InsertSelectedCompletion() {
        string selected = completionList.SelectedItem.ToString(); string current = GetCurrentWord();
        sqlInput.Select(sqlInput.SelectionStart - current.Length, current.Length); sqlInput.SelectedText = selected;
        completionList.Visible = false; ColorizeSql();
    }
    private void ColorizeSql() {
        if (_isColoring) return; _isColoring = true;
        int pos = sqlInput.SelectionStart, len = sqlInput.SelectionLength;
        sqlInput.SelectAll(); sqlInput.SelectionColor = Color.Black; sqlInput.SelectionFont = new Font(sqlInput.Font, FontStyle.Regular);
        string[] kw = new string[] { "SELECT", "FROM", "WHERE", "JOIN", "ON", "LEFT", "LIMIT", "ORDER", "BY", "AND", "OR", "AS", "COUNT", "DISTINCT" };
        ApplyHighlight(sqlInput.Text, kw, Color.Blue, FontStyle.Bold);
        lock (activeData) { ApplyHighlight(sqlInput.Text, activeData.Keys.ToArray(), Color.DarkMagenta, FontStyle.Bold); }
        sqlInput.Select(pos, len); sqlInput.SelectionColor = Color.Black; _isColoring = false;
        UpdateTripleBuffer(); 
    }
    private void ApplyHighlight(string content, string[] words, Color color, FontStyle style) {
        foreach (string word in words) {
            int start = 0; while ((start = content.IndexOf(word, start, StringComparison.OrdinalIgnoreCase)) != -1) {
                bool pre = start > 0 && char.IsLetterOrDigit(content[start - 1]);
                bool post = start + word.Length < content.Length && char.IsLetterOrDigit(content[start + word.Length]);
                if (!pre && !post) { sqlInput.Select(start, word.Length); sqlInput.SelectionColor = color; sqlInput.SelectionFont = new Font(sqlInput.Font, style); }
                start += word.Length;
            }
        }
    }
    private void UpdateLineCount() {
        if (tabs.SelectedTab == null) { lineCountLabel.Text = "Rows: 0"; return; }
        DataGridView dgv = tabs.SelectedTab.Controls.OfType<DataGridView>().FirstOrDefault();
        if (dgv != null && dgv.DataSource is DataTable) lineCountLabel.Text = "Rows: " + ((DataTable)dgv.DataSource).Rows.Count;
    }

    [STAThread] static void Main() { Application.EnableVisualStyles(); Application.Run(new DataApp()); }
}